---
id: 563
title: SF Bay Area day trips with no car (or planning!) needed
date: 2015-05-26T09:13:42+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=563
permalink: /2015/05/26/sf-bay-area-day-trips-no-car-planning/
categories:
  - Uncategorized
---
I had breakfast yesterday, one table over from an adorable older couple from Pittsburg, so obviously Ashley​ and I made friends. They had such a great SF vacation plan. All their day-trips were tours with no car needed (to Napa, Carmel, Pebble Beach, Muir Woods).

Why don&#8217;t we do these day-trips while living here?? Not just &#8220;let&#8217;s be tourists in our own city!&#8221; &#8211; I didn&#8217;t realize you don&#8217;t need to spend the time/$$ on car, hotel, planning yourself.

Have you done a great day-trip like this? Or know a good site to find them? I&#8217;ll update this post with the best ones I hear from or find myself. Ideally:

* leave from downtown SF
  
* provide all transport/food/tours
  
* NOT a party bus
  
* diverse fellow tour-takers