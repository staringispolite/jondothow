---
id: 322
title: Vacation infographic
date: 2012-08-16T11:00:44+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=322
permalink: /2012/08/16/vacation-infographic/
categories:
  - art
---
Ok, I can verify that the [FF Chartwell](http://staringispolite.com/blog/2012/08/15/ff-chartwell-the-infographic-typeface/ "FF Chartwell – The Infographic Typeface") family makes it really easy to make Infographics

<div class="wp-caption aligncenter" style="width: 458px">
  <a href="http://sphotos-b.xx.fbcdn.net/hphotos-ash4/424216_10101232135532368_1193988380_n.jpg" target="_blank"><img class="      " src="http://sphotos-b.xx.fbcdn.net/hphotos-ash4/424216_10101232135532368_1193988380_n.jpg" alt="" width="448" height="347" /></a>
  
  <p class="wp-caption-text">
    As you can see from the graphics, throughout the week, I've been slowly slipping into a state of hibernation.
  </p>
</div>

&nbsp;