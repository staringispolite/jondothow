---
id: 64
title: Hidden Passageways
date: 2008-05-13T11:07:42+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=64
permalink: /2008/05/13/hidden-passageways/
categories:
  - unique
---
Have you always wanted to build that secret hiding place, meeting room, or dungeon, but can&#8217;t afford the maniacal henchmen builders?  Tired of wasting precious turns with uncertain dice-rolling, just to get from The Library to The Study?  Well now you can resolve all your secret passageway needs at one place:

<a href="http://www.hiddenpassageway.com/" target="_blank">http://www.hiddenpassageway.com/</a>

Check out the gallery &#8211; they&#8217;ve got a full working pantry that folds back into the wall to reveal a hidden dungeon, er, basement.