---
id: 292
title: Randomized Garfield comics
date: 2012-06-18T22:59:52+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=292
permalink: /2012/06/18/randomized-garfield-comics/
categories:
  - Uncategorized
---
Someone &#8220;noticed that Garfield comics make just as much sense if you throw random panels together, and sometimes are actually pretty funny. He got a cease and desist letter. So he made the code available for people who wanted to try it for themselves.&#8221;

This is one of the mirrors:

http://www.dougshaw.com/garfield.html?3yearsislongenough

I don&#8217;t think they make &#8220;just as much&#8221; sense randomized, but since the ones that DO make sense weren&#8217;t all that much funnier, it works surprisingly well. Clever enough that it&#8217;s worth sharing (and viewing source if you&#8217;re a coder).

I suspect it&#8217;s possible to do with Cathy comics too&#8230; maybe I&#8217;ll try that this weekend  <img src='http://staringispolite.com/blog/wp-includes/images/smilies/icon_smile.gif' alt=':)' class='wp-smiley' />