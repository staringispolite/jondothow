---
id: 273
title: Just a Normal Video Chat
date: 2012-03-26T16:29:56+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=273
permalink: /2012/03/26/just-a-normal-video-chat/
categories:
  - humor
---
<div id="attachment_274" class="wp-caption aligncenter" style="width: 1584px">
  <a href="http://staringispolite.com/blog/wp-content/uploads/2012/03/Jonathan-Howard-normal-video-chat.jpg"><img class="size-full wp-image-274" title="Jonathan-Howard-normal-video-chat" src="http://staringispolite.com/blog/wp-content/uploads/2012/03/Jonathan-Howard-normal-video-chat.jpg" alt="" width="1574" height="760" /></a>
  
  <p class="wp-caption-text">
    Just a normal video chat with the family back home
  </p>
</div>

&#8220;What are you doing?&#8221;
  
&#8220;Nothing, normal stuff.&#8221;