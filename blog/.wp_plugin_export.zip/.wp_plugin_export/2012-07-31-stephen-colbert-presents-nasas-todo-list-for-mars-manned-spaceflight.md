---
id: 313
title: 'Stephen Colbert presents Nasa&#8217;s TODO list for Mars manned spaceflight'
date: 2012-07-31T00:40:36+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=313
permalink: /2012/07/31/stephen-colbert-presents-nasas-todo-list-for-mars-manned-spaceflight/
categories:
  - humor
---
I was watching the Tuesday, July 24th episode of The Colbert Report tonight, and caught this gem with some precision pausing and rewinding. I love the little things like this, and it makes me wonder who in their army of interns spent the time to flesh this list out.

<div class="wp-caption aligncenter" style="width: 524px">
  <a href="http://www.hulu.com/watch/384036"><img class="  " title="Stephen Colbert's Nasa's Mars TODO list" src="http://i.imgur.com/sY88G.png?1" alt="" width="514" height="300" /></a>
  
  <p class="wp-caption-text">
    Stephen Colbert's Nasa's Mars TODO list
  </p>
</div>

<!--more-->TO DO:

  1. Figure out menu
  2. Make flight music playlist
  3. Watch Total Recall
  4. Watch Total Recall remake
  5. Call Neil DeGrasse Tyson
  6. Brag to ex-girlfriend from high school
  7. Drive cross-country wearing diaper
  8. Build spaceship
  9. Figure out how to sustain life on Mars
 10. Find three-breasted woman