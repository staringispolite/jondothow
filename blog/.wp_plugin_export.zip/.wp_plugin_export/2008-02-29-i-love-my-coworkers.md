---
id: 77
title: I love my coworkers
date: 2008-02-29T00:03:45+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=77
permalink: /2008/02/29/i-love-my-coworkers/
categories:
  - humor
---
At the gym yesterday:

Pat: &#8220;Man, I&#8217;m getting weaker.&#8221;
  
Me: &#8220;I&#8217;m getting stronger!&#8221;
  
Paul: &#8220;I&#8217;m getting a pimple!&#8221;