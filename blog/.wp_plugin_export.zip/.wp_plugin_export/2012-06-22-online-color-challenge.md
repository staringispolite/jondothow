---
id: 297
title: Online color challenge
date: 2012-06-22T14:10:00+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=297
permalink: /2012/06/22/online-color-challenge/
categories:
  - Uncategorized
---
How well can you see colors? Women reportedly do better than men, and designers/artists tend to do better than engineers:

<div class="wp-caption alignnone" style="width: 976px">
  <a href="http://www.xrite.com/custom_page.aspx?pageid=77&lang=en"><img class=" " title="Online color challenge" src="http://i.imgur.com/ywyQe.png" alt="" width="966" height="343" /></a>
  
  <p class="wp-caption-text">
    Can you put these in order by hue?
  </p>
</div>

<a title="Click to take the Online Color Challenge" href="http://www.xrite.com/custom_page.aspx?pageid=77&lang=en" target="_blank">http://www.xrite.com/custom_page.aspx?pageid=77&lang=en</a>

<div>
   My score was 3 (best possible is 0). See if you can beat me!
</div>