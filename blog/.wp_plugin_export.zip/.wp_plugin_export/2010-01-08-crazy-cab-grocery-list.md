---
id: 54
title: Crazy Cab Grocery List
date: 2010-01-08T00:29:50+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=54
permalink: /2010/01/08/crazy-cab-grocery-list/
categories:
  - humor
---
Wednesday night, my roommate Lindsay and I found this gem of a grocery list on the seat of the cab on the way to Smash Brothers Night at The Classy Apmt (east coast division).

I&#8217;ll forever wonder whether they dropped it before or after they got their groceries&#8230; I&#8217;ll try to transcribe some highlights, but honestly, all the fun is in figuring out what the heck they actually meant. I also wonder if this only makes no sense because I just haven&#8217;t yet found this off-brand grocery store, where everything **sounds like** a product you&#8217;ve heard of, but is 30% off (in terms of both price, and spelling accuracy). Here&#8217;s the list:

- Big columbo fat free <span style="text-decoration: line-through;">vinalla</span> vinnalla
  
- 2 break texture hearty
  
- 2 water spring water
  
- One promise light
  
- <span style="text-decoration: underline;">2 toilet</span> paper one to get

&#8230;And so much more to love in the image. I hope they found everything they were looking for.

<div id="attachment_59" class="wp-caption aligncenter" style="width: 810px">
  <a href="http://staringispolite.com/blog/wp-content/uploads/2010/01/grocery-list.jpg"><img class="size-full wp-image-59" title="grocery list" src="http://staringispolite.com/blog/wp-content/uploads/2010/01/grocery-list.jpg" alt="" width="800" height="600" /></a>
  
  <p class="wp-caption-text">
    Found grocery list. Interpret at your own risk.
  </p>
</div>