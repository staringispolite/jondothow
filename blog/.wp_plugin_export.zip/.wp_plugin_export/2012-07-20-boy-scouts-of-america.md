---
id: 309
title: Boy Scouts of America
date: 2012-07-20T12:42:28+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=309
permalink: /2012/07/20/boy-scouts-of-america/
categories:
  - Uncategorized
---
As a child, my parents didn&#8217;t allow me to join the Boy Scouts of America in protest of their discriminatory policies towards gays. As an adult, I&#8217;m glad they didn&#8217;t.

It&#8217;s very inspiring to see this (not gay) Eagle Scout&#8217;s letter as he returns his Eagle Scout badge because he &#8220;cannot in good conscience hold this badge as long as the BSA continues a policy of bigotry&#8221;.

<p style="text-align: center;">
  Even more inspiring to see the measured & mature method in which he goes about it.
</p>

<img class="aligncenter" title="Letter from an Eagle Scout to the Boy Scouts of America" src="http://i.imgur.com/XJNny.jpg" alt="" width="462" height="589" />