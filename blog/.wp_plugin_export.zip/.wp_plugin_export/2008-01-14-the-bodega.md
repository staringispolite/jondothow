---
id: 87
title: The Bodega
date: 2008-01-14T00:26:29+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=87
permalink: /2008/01/14/the-bodega/
categories:
  - unique
---
One of the (very welcome) interruptions during the <a href=" http://staringispolite.com/blog/2008/01/13/finally-settled-in/" data-cke-saved-href="http://supernova-7.livejournal.com/14897.html">marathon IKEA construction effort of 2008</a>. was when Casey came in with his roommate Pablo and asked if we wanted to go with them on a quest to find a secret shoe store they&#8217;d heard of called &#8220;The Bodega.&#8221;

We drove into Boston, picked up Casey&#8217;s 3rd roommate, and started our quest.  Technically, I guess the quest proper ended about 60 seconds later because Casey had somehow found its address online on some obscure forum.

It turned out to be closed early on Sunday.  (We were 15 minutes late at 5:15!  Blast!)  But here&#8217;s why I don&#8217;t care that it took a half hour away from quality pizza and IKEA building time:

The Bodega has no website, no phone number, and not even sign outside.  In fact, the storefront is actually a run-down dirty completely unremarkable convenience store, also with no sign.  Apparently, some people walk in, grab some food, a touristy thing, or a drink&#8230; then pay at the register and leave, never knowing any better.

But supposedly, if you go up to the Snapple machine in the back, find a specific broken tile, and push it down with your foot&#8230; the Snapple machine rolls to the side and reveals an entranceway to&#8230; The Bodega.

According to what Casey heard, The Bodega itself is a secret shoe store that has rare or vintage shoes that are extremely hard to find anywhere else.  I&#8217;m not even that into the whole shoe culture (a friend of mine from UMD&#8217;s art program used to collect rare shoes and had a collection worth many 1000&#8242;s of dollars) but I&#8217;m ridiculously excited to see what they&#8217;ve got.

When we got there and the door was locked, we did get the girl at the convenience store cash register to come to the door though.  We got some minor verification when she didn&#8217;t question anything when we asked about The Bodega&#8217;s business hours.  They close at 6 tomorrow.

So we hopped back into Casey&#8217;s car, disappointed but bouncing from excitement that we actually may have found it.  Then &#8211; and I&#8217;m not making this up &#8211; as we pulled away, over the top of soap boxes and ancient-looking cans of food in the window, through the dirty yellowed glass, we saw the Snapple machine in the back corner of the convenience store.  It was sliding away to the left, and a bright light shone from behind it.

I can&#8217;t friggin wait.