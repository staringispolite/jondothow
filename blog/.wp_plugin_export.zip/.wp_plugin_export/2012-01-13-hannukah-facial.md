---
id: 52
title: 'Hannukah Facial*'
date: 2012-01-13T01:16:38+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=52
permalink: /2012/01/13/hannukah-facial/
categories:
  - humor
---
<address>
  I want to quickly make it known to the world that I&#8217;m currently living out a modern day miracle, worthy of at least notoriety in future millennia, if not full-blown minor holiday status.</p> 
  
  <p>
    My $5 container of <a href="http://bit.ly/515pn3" data-cke-saved-href="http://bit.ly/515pn3">CVS-brand facial soap</a> looked like it was going to run out in November. It has still not done so, 6 weeks later.
  </p>
  
  <p>
    6 WEEKS LATER!
  </p>
  
  <p>
    I keep forgetting to throw it away every time I take a shower and remember it was empty last time, only to shrug, give it a shake for the hell of it, and get <strong>another serving of soap</strong> before it&#8217;s nothing but air again. <em>&#8216;Surely it must be out for good this time&#8217;</em> I think, and make a mental note to throw it out. But I don&#8217;t. To paraphrase the great Dr. Hershel Pantine: <em>&#8220;I rinse&#8230; and I repeat.&#8221;</em> And it happens again!
  </p>
  
  <p>
    Now, I don&#8217;t use that face soap every day, which slightly blunts the amazing longevity here, but come on &#8211; the ancient Jews only managed to scrape 6 extra DAYS out of basically an oil can, and that&#8217;s a full-fledged world-wide holiday in the Jewish calendar!
  </p>
  
  <p>
    And I don&#8217;t mean to belittle Hannukah, I often celebrate it with my family when I&#8217;m home for winter break, and did so every year growing up. But if I learned one thing from the Old Testament &#8211; and I certainly wouldn&#8217;t give myself much <em>more</em> credit than one here - surely a basic substance-availability misjudgement of this magnitude and persistence must mean something. Do you have any ideas? Any sufferings this might harken an end to? Perhaps a people I might bring news unto? Let me know in the comments, I don&#8217;t want to miss this opportunity!
  </p>
  
  <p>
    *Fine print: sexual manner of title acknowledged, but not intended, by author. Alternate title &#8216;Shower-time Menorah&#8217; not much better. 
  </p>
</address>