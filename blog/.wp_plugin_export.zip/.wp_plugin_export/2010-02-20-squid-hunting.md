---
id: 41
title: Squid Hunting
date: 2010-02-20T23:33:32+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=41
permalink: /2010/02/20/squid-hunting/
categories:
  - adventure
---
I&#8217;m going deep sea squid fishing tomorrow morning! Don&#8217;t usually do things that are this &#8220;hunting&#8221;-y, but I figure it&#8217;s a once-in-a-lifetime thing when a friend asks if you want to charter a boat and hunt 4&#8243; squid miles off the coast in the Pacific Ocean.

Also, they&#8217;re Humboldt Squid, which are apparently supposed to be no further north than LA, but with the warmer-than-normal water, they&#8217;re swimming all the way up here to SF, and eating everything around. So technically, **it is our ecological duty to harpoon them** and return balance to the world.

More on the trip [here](http://www.hulicat.com/fishing/squid.html "here") and here&#8217;s a little preview of what we&#8217;re up against:

<div class="wp-caption aligncenter" style="width: 510px">
  <img title="Squiiiid!" src="http://farm5.static.flickr.com/4071/4375294706_323b9eb7f3.jpg" alt="Squiiiid!" width="500" height="375" />
  
  <p class="wp-caption-text">
    The Evil Humboldt Squid
  </p>
</div>