---
id: 62
title: http://www.christophehuet.com/
date: 2008-05-27T12:19:43+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=62
permalink: /2008/05/27/christophe-huet/
categories:
  - art
---
Amazing photomanipulation artist with a huge gallery:

<a href="http://www.christophehuet.com/" target="_blank">http://www.christophehuet.com/</a>

He&#8217;s got a great &#8220;making of&#8221; section that steps through the process for his more complex pieces, too.  Really interesting stuff.