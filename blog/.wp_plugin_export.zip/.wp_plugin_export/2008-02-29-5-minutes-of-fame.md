---
id: 82
title: 5 minutes of fame
date: 2008-02-29T00:29:59+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=82
permalink: /2008/02/29/5-minutes-of-fame/
categories:
  - educational
  - entertainment
---
If we all have 5 minutes of fame, I now have 4 minutes 54 seconds.

I was on the History Channel for 5 1/2 seconds today!  it airs again Saturday night at 7pm (Modern Marvels)  The Univ. of Maryland lab I used to work at (http://www.cattlab.umd.edu) does a really cool video-game-turned-training-simulation for first responders, and it was featured on Modern Marvels tonight, at the end of an episode on highway systems around the world.  And, for no reason at all, I&#8217;m in the background for a couple shots. Hey, I&#8217;ll take what I can get.  Check it out this Sat if you can!  The episode was actually fairly entertaining (but maybe only because I worked in traffic engineering field for a while&#8230;?  Who knows!)