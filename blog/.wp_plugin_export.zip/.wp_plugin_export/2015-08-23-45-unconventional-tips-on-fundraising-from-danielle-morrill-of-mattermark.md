---
id: 567
title: 45+ Unconventional Tips on Fundraising from Danielle Morrill of Mattermark
date: 2015-08-23T15:46:49+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=567
permalink: /2015/08/23/45-unconventional-tips-on-fundraising-from-danielle-morrill-of-mattermark/
categories:
  - Uncategorized
---
<a href="https://twitter.com/DanielleMorrill" target="_blank">Danielle</a> unleashed a Category-5 tweetstorm on fundraising today, but twitter isn&#8217;t showing parent/child replies right for me, so following the thread got difficult. Made this for my own sanity; publishing here in case it&#8217;s useful for others. Here it is, in order (including some of the asides):

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    1) Fundraising this fall? I have some unconventional tips for you to make your experience awesome
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635516561139216388">August 23, 2015</a>
  </p>
</blockquote>

&nbsp;

<blockquote class="twitter-tweet" lang="en">
  <p>
    3) Sequoia is surprisingly difficult to find (perhaps an intelligence test?) so plan for extra time to get a parking spot
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635517038010593280">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p lang="en" dir="ltr">
    <a href="https://twitter.com/DanielleMorrill">@DanielleMorrill</a> when visiting <a href="https://twitter.com/sequoia">@sequoia</a> take the car from the <a href="https://twitter.com/RosewoodHotels">@RosewoodHotels</a> across the street. They know where to drop you off.
  </p>
  
  <p>
    &mdash; Alexander Muse (@amuse) <a href="https://twitter.com/amuse/status/635588192348020736">August 23, 2015</a>
  </p>
</blockquote>

&nbsp;

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    5) avoid the Sharon Heights Starbucks
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635517542115622912">August 23, 2015</a>
  </p>
</blockquote>


  
<!--more-->

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    7) if you want a signed term sheet by the end of October start requesting meetings now
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635518134414274560">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    9) also Khosla has the most incredible garden outside the window with plants so big it&#8217;s like Alice in Wonderland
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635518728373841920">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    11) Accel is in downtown Palo Alto, so plan time before or after to get some macaroons on University Ave (in the downtime between meetings)
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635520033892888576">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    13) early morning breakfasts at obscure spots are the real getting-to-know-you signal
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635520543375036418">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    15) Ladies, skip the heels. A lot of investors like to do walking meetings, no need to suffer.
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635521530424766464">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    17) people talk about 10 &#8220;brand name&#8221; VCs but you should plan to pitch 30+ firms. There are very good less visible investors
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635522422448369664">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    19) ladies, it may look like the set of Mad Men but unless you normally wear dresses just stick with normal clothes and good hygiene
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635523595649740800">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    21) okay back to unconventional stuff&#8230; Don&#8217;t be rude to assistants or other staff EVER
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635526147053219844">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    23) regarding power moves, investors know what you are doing and yes it will work on some&#8230; But huge turn off to others. Know your audience
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635526468693544960">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    I've raised $11 million and still believe this is the best way to do business <a href="https://t.co/bi3UrrBS05">https://t.co/bi3UrrBS05</a>
  </p>
  
  <p>
    &mdash; Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635595227579809792">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    <a href="https://twitter.com/DanielleMorrill">@DanielleMorrill</a> unless you've raised millions before, don't be too clever by half and try to play a power move. Be humble. Be yourself.
  </p>
  
  <p>
    &mdash; Alexander Muse (@amuse) <a href="https://twitter.com/amuse/status/635593898023362560">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    25) you need a CRM or at least spreadsheet to keep track of your VC relationships. Kids names, hobbies, companies they&#8217;re proud of
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635528979231801344">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    27) the sandwiches in the Sharon Heights deli are killer
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635530888911020032">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    29) from my cofounder <a href="https://twitter.com/MisterMorrill">@MisterMorrill</a> &#8220;do your research beforehand and look who does deals in your space, only talk to people you want&#8221;
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635533244499292160">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    31) if you raised $3M+ in seed money you are competing with Series A *and* Series B candidates
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635534307621122048">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en" data-conversation="none">
  <p lang="en" dir="ltr">
    32) don&#8217;t overdo it on slide design, it&#8217;s like a house that&#8217;s been on the market too long and is over-staged
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635534590573019136">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    <a href="https://twitter.com/rabois">@rabois</a> <a href="https://twitter.com/DanielleMorrill">@DanielleMorrill</a> Depends on the numbers. <img src='http://staringispolite.com/blog/wp-includes/images/smilies/icon_smile.gif' alt=':)' class='wp-smiley' />
  </p>
  
  <p>
    — Marc Andreessen (@pmarca) <a href="https://twitter.com/pmarca/status/635563747633860612">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    Listen up&#8230; This is a consumer investor and I do not know much about that side <a href="https://t.co/yp3zs17A3H">https://t.co/yp3zs17A3H</a>
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635535476200378368">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    Have your designer give you a nice on brand template but don&#8217;t go crazy with transitions or graphics <a href="https://t.co/VtH8p0csyR">https://t.co/VtH8p0csyR</a>
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635535654311432192">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    34) at the end of the day, go home to your support network and share your thorns and roses (learned this from <a href="https://twitter.com/chrisfhoward">@chrisfhoward</a>&#8216;s 3 boys)
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635538808935596032">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en" data-conversation="none">
  <p lang="en" dir="ltr">
    When getting breakfast with a VC, eat beforehand, so you don&#8217;t do this: <a href="https://twitter.com/DanielleMorrill">@DanielleMorrill</a> <a href="https://twitter.com/rabois">@rabois</a> <a href="https://twitter.com/jasonlk">@jasonlk</a> <a href="http://t.co/lJsSTgj2RD">pic.twitter.com/lJsSTgj2RD</a>
  </p>
  
  <p>
    — Adam Khan (@Khanoisseur) <a href="https://twitter.com/Khanoisseur/status/635537459162558464">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    When you do a VC partner pitch, your champion is already sold. So it&#8217;s mostly about YOU as CEO. Do rest believe? <a href="https://t.co/sxZpPkOPHY">https://t.co/sxZpPkOPHY</a>
  </p>
  
  <p>
    — Jason M. Lemkin (@jasonlk) <a href="https://twitter.com/jasonlk/status/635538550432378880">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    4/ founders must lead the charge on a raise. VC&#8217;s want to see the personality behind the company. Investment is in ppl too.
  </p>
  
  <p>
    — Jeremy Shure (@JeremyShure) <a href="https://twitter.com/JeremyShure/status/635539075357933568">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en" data-conversation="none">
  <p lang="en" dir="ltr">
    /15 practice like you play. Every practice pitch should be like the real thing. You want people to challenge you in practice.
  </p>
  
  <p>
    — Jeremy Shure (@JeremyShure) <a href="https://twitter.com/JeremyShure/status/635541623565365248">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    36) if you&#8217;re not used to living by your calendar this will be really annoying. build in lots of buffer time for travel, food, and bathroom!
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635541363786973184">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    38) same deal with Coupa Cafe, The Creamery, Small Foods, 21st Amendment, The Battery &#8212; only do it once you have 2 term sheets <img src='http://staringispolite.com/blog/wp-includes/images/smilies/icon_cool.gif' alt='8-)' class='wp-smiley' />
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635542467740237824">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    40) ladies here are some examples of pitch appropriate attire <a href="http://t.co/mMBljmC8rA">pic.twitter.com/mMBljmC8rA</a>
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635554445946785792">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    <a href="https://twitter.com/DanielleMorrill">@DanielleMorrill</a> great advice from <a href="https://twitter.com/davidsze">@davidsze</a>, if you want to raise a $10m Series A, ask for $3m, get multiple term sheets, and negotiate up.
  </p>
  
  <p>
    — Rick Morrison (@morrisor) <a href="https://twitter.com/morrisor/status/635552132674916352">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en" data-conversation="none">
  <p lang="en" dir="ltr">
    <a href="https://twitter.com/DanielleMorrill">@DanielleMorrill</a> 40+) No matter how tempting, don&#8217;t fly in on the red eye & pitch the same day. Pace yourself wisely.
  </p>
  
  <p>
    — Ana Milicevic (@aexm) <a href="https://twitter.com/aexm/status/635554684539957248">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    42) you only fail if you stop trying to raise, we flunked out in the A round the first time <a href="https://twitter.com/bwertz">@bwertz</a> <a href="https://twitter.com/speechu">@speechu</a> and <a href="https://twitter.com/chazard">@chazard</a> had our backs
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635561298906869765">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    44) make a playlist of music that makes you feel like a BOSS. Music you find yourself strutting to. Music that reveals your best self.
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635567410079100928">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en" data-conversation="none">
  <p lang="en" dir="ltr">
    45) leave it all on the court
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635567470917476352">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    Words from a fundraising master&#8230; <a href="https://t.co/iY8apOZZRu">https://t.co/iY8apOZZRu</a>
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635568993542082560">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    47) raising seed funding is like being 15, I&#8217;d love to be that skinny but never actually want to go back to being that much of a n00b again.
  </p>
  
  <p>
    — Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635586660999163904">August 23, 2015</a>
  </p>
</blockquote>

&nbsp;

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    16/ have fun, be grateful for the oppty. U could be picking rocks but instead you’re pitching 4 $$$ at alternate universe prices.
  </p>
  
  <p>
    &mdash; Mark Organ (@markorgan) <a href="https://twitter.com/markorgan/status/635584031426498560">August 23, 2015</a>
  </p>
</blockquote>

<blockquote class="twitter-tweet" lang="en">
  <p lang="en" dir="ltr">
    You are tweeting my heart here, 100% feel this <a href="https://t.co/rKMgBLEWtA">https://t.co/rKMgBLEWtA</a>
  </p>
  
  <p>
    &mdash; Danielle Morrill (@DanielleMorrill) <a href="https://twitter.com/DanielleMorrill/status/635592444067737600">August 23, 2015</a>
  </p>
</blockquote>