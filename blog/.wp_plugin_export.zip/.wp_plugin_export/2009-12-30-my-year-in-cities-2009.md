---
id: 56
title: My Year in Cities, 2009
date: 2009-12-30T20:24:26+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=56
permalink: /2009/12/30/my-year-in-cities-2009/
categories:
  - adventure
---
Inspired by <a href="http://www.magicspatula.com/blog/2009/12/29/my-year-in-cities-2009/" data-cke-saved-href="http://www.magicspatula.com/blog/2009/12/29/my-year-in-cities-2009/">Matt Casey&#8217;s post</a> by the same name, and thus indirectly by <a href="http://www.kottke.org/08/12/my-year-in-cities-2008" data-cke-saved-href="http://www.kottke.org/08/12/my-year-in-cities-2008">kottke&#8217;s post as well</a>, here is my Year in Cities, for 2009. In bold are the places I hadn&#8217;t been before.

Cambridge, MA
  
**Somerville, MA**
  
Boston, MA
  
**Avon, CT**
  
Denver, CO
  
Killington, VT
  
New York, NY
  
**Brooklyn, NY**
  
Weehawken, NJ
  
Washington, DC
  
San Francisco, CA
  
Mountain View, CA
  
**Jupiter, FL**

Not terribly impressive (2008 would&#8217;ve also included London, Rome, Vatican City, & elsewhere in the US) but not too shabby either! I hope 2010 will be better&#8230; Boston, DC, and SF will pop up again, hopefully something exotic as well&#8230; Alaska? Ireland? Another jaunt about europe? I doubt it. But I can dream, America. I can dream.