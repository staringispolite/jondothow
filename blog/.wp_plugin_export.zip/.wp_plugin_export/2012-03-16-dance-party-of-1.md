---
id: 208
title: Dance, Party of 1?
date: 2012-03-16T13:53:06+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=208
permalink: /2012/03/16/dance-party-of-1/
categories:
  - Uncategorized
---
[![](http://i2.ytimg.com/vi/-d_PZikUT2I/hqdefault.jpg)](http://www.youtube.com/watch?v=-d_PZikUT2I)
  
[Gotye &#8211; Somebody That I Used To Know, feat. Kimbra (4FRNT Remix)](http://www.youtube.com/watch?v=-d_PZikUT2I)

This is the best remix of Gotye&#8217;s _Somebody That I Used To Know_ that I&#8217;ve heard. Ashley and I found one mix of the song through a lucky cab ride radio station, and Shazam for iPhone, then went looking for the version we heard. I never did find that radio version, and the original is a little slow for my tastes. But this. This is a new favorite. (Even Gotye himself is a fan)

> <a href="https://twitter.com/#!/4FRNTmusic" rel="nofollow" data-screen-name="4FRNTmusic"><s>@</s><strong>4FRNTmusic</strong></a>&#8216;s mix of Somebody- hands down the craftiest and most exciting dance remix I&#8217;ve heard of the track
  
> <a title="[Original tweet]" href="https://twitter.com/#!/gotye/status/164536067255582720" target="_blank">https://twitter.com/#!/gotye/status/164536067255582720</a>
> 
> &nbsp;

4FRNT seems to be extremely new, so if you like it there&#8217;s no high quality download link. But this music blog has the best one I&#8217;ve found. (Not DJ quality, but sounds great in headphones!) <a href="http://ilspins.com/somebody-that-i-used-to-know-feat-kimbra-4frnt-remix/" target="_blank">http://ilspins.com/somebody-that-i-used-to-know-feat-kimbra-4frnt-remix/</a>