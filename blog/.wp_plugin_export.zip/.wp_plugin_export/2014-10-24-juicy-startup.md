---
id: 507
title: 'Biggie Smalls &#8211; Juicy (Startup Edition)'
date: 2014-10-24T13:08:34+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=507
permalink: /2014/10/24/juicy-startup/
categories:
  - Uncategorized
---
So&#8230; this happened.

Some nights you accidentally &#8220;Weird Al&#8221; a whole Biggie verse about startups. We&#8217;ve all been there. \*cough\*. Here&#8217;s the original, play it and read along!


  
<!--more-->

<blockquote class="twitter-tweet" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> I used to read Start Up magazine! Om & Morin & Marc Andree up in the Series Seed
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525515962439581696">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> Hangin mockups on my wall&#8230; Every Saturday, launch a hack, blogs from Nivi & Naval
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525516610711203840">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> I let my deck rock till my deck pop. Drawin' screens w/ Bamboo, building up a private doc
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525518140797501440">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> Way back, revenues never black, no market cap. Heart attacks to match.
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525520101861109760">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" data-cards="hidden" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> Remember Mayer's laugh, nyyyye-ha nye-ha <a href="http://t.co/xs05DOIEaF">http://t.co/xs05DOIEaF</a>&#10;You never thought tech stocks could take us this far
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525521375352475648">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> Now I'm in the limelight, market timed right. Time to get paid, Distrupt like I'm Kincaid
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525522710781108224">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> Code tiller. The opposite of a winner. Remember when I used to eat Boudin's for dinner.
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525525652208771072">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> Peace to Ron C, Chrissy D, and P.G. Friends & the fam, Mom & Dad's money.
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525526738462203904">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> I'm blowin up like you THOUGHT I would. Call the cell, same number, same hood. It's all good.
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525527177186377729">October 24, 2014</a>
  </p>
</blockquote>



<blockquote class="twitter-tweet" data-conversation="none" lang="en">
  <p>
    <a href="https://twitter.com/Quan">@Quan</a> <a href="https://twitter.com/ericnakagawa">@ericnakagawa</a> (And if ya don't code, now ya code)&#10;*drops mic*
  </p>
  
  <p>
    &mdash; Jonathan Howard (@staringispolite) <a href="https://twitter.com/staringispolite/status/525528184909856768">October 24, 2014</a>
  </p>
</blockquote>