---
id: 89
title: Finally Settled In
date: 2008-01-13T23:38:07+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=89
permalink: /2008/01/13/finally-settled-in/
categories:
  - Uncategorized
---
\*phew\*

Today was a busy day.

The apartment we&#8217;re taking over used to be Casey&#8217;s (<a href="http://freecause.com/about/management/" data-cke-saved-href="http://freecause.com/about/management/">The CFO</a> at <a href="http://freecause.com/" data-cke-saved-href="http://freecause.com/">FreeCause</a>.)  He and his roommates happened to be moving out just in time.  After we got there, FreeCause realized that their new office space wouldn&#8217;t be ready in two weeks like they planned, making the old office &#8211; an awesome loft &#8211; not available for us to live in when they move like they planned.  So, luckily for us, Casey and his roommates were moving next door to a bigger place, so we just took over their old apartment.  Sweet timing, not to mention the perks of having 3 friends next-door when you need help moving and the yet-to-be-discovered perks of living next-door to the CFO of your company.

Casey went to MIT before he left to help start FreeCause, so this place is right on MIT&#8217;s campus, overlooking the Charles river.  It&#8217;s <a href="http://flickr.com/photos/patjenk/2186323639/in/set-72157603697833407/" data-cke-saved-href="http://flickr.com/photos/patjenk/2186323639/in/set-72157603697833407/">a really great view.</a>

Last night was Lauren&#8217;s birthday (the girlfriend of Justin, one of our co-founders) and they had a party at Justin&#8217;s apartment complex&#8217;s swanky game room until about 1.  Then we tried to head to someone&#8217;s favorite bar in Cambridge, only to discover that Cambridge bars close at 1.  (Note to self:  never again leave somewhere for a Cambridge bar)

I woke up around 9:30 and we all took the T into Boston to have breakfast at FreeCause and go to <a href="http://www.mysportsclubs.com/Default.aspx" data-cke-saved-href="http://www.mysportsclubs.com/Default.aspx">the gym we joined</a>, which is right across the street.  Then we had to be back in Cambridge at our apartment by 2 to wait for IKEA to bring us our bedrooms.  (Late last week Casey took us apartment shopping for beds, desks, a dining room table, chairs etc.)  The unloading itself wasn&#8217;t that bad.  But then constructing all our stuff took from about 3 until 11.  (Interspersed with pizza and NFL playoff games on TV)

Also, I learned something about myself today:  I&#8217;m really terrible at reading IKEA instructions.  In my defense, some of the pictures don&#8217;t actually look like the screws they should.  And certain details like &#8220;the front and back chair pieces are exactly the same, except one is an inch longer and it won&#8217;t work if you switch them.&#8221; are glossed over, showing two seemingly identical pieces of wood with dotted lines going into the chair sides.  It&#8217;s not even that I&#8217;m bad with tools &#8211; I&#8217;ve made bookcases, bunkbeds, entertainment centers, etc before&#8230; but something just did NOT click with IKEA&#8217;s instructions.  It took me 3 tries to put together a simple dining room chair&#8230;  I blazed my way through it in roughly the time it took Pat to assemble the other 3 plus the table itself.  Then I fell asleep on the couch.

When I woke up, Pat and Paul had already finished their beds and tables.

From there, I think you can guess the theme of the evening  <img src='http://staringispolite.com/blog/wp-includes/images/smilies/icon_smile.gif' alt=':)' class='wp-smiley' />  BUT!  I&#8217;m all settled in now.  My bed frame is built, bed is made, desk is built, my desk chair is built, and my computer is set up.

I officially live in Cambridge.