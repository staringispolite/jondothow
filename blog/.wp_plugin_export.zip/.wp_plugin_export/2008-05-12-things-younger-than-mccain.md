---
id: 66
title: Things Younger Than McCain
date: 2008-05-12T13:18:18+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=66
permalink: /2008/05/12/things-younger-than-mccain/
categories:
  - humor
---
<a href="http://www.thingsyoungerthanmccain.com/" data-cke-saved-href="http://www.thingsyoungerthanmccain.com/">http://www.thin<wbr>gsyoungerthanmc<wbr>cain.com/</wbr></wbr></a>

Some of my favorites:

  * The invention of the ball-point pen.
  * Alaska.
  * Mount Rushmore.

Disclaimer:
  
I don&#8217;t advocate age-ism &#8211; he&#8217;s apparently in fine health.  But I do happen to dislike McCain&#8217;s bid for president for other reasons. (He&#8217;s disturbingly nonchalant about war. He&#8217;s admitted in his own words he knows very little about the economy. His &#8220;flip-flopping&#8221; to quickly court the hard-line religious right this year, after a lifetime of finding middle-ground between parties makes me suspect any position he takes.)  It&#8217;s a shame really, because I used to really respect him for being &#8220;different&#8221; from the hard-liners.

And I suppose there is an argument to be made for having more of relevant life experiences.  But when <a href="http://en.wikipedia.org/wiki/List_of_current_United_States_Senators_by_age" target="_blank">the average official in congress was out of college before the Internet even began</a>, and the nation is facing so many new technological challenges, maybe now&#8217;s not the time to elect our oldest president ever?