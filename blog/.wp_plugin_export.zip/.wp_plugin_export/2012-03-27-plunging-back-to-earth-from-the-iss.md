---
id: 277
title: Plunging back to Earth from the ISS
date: 2012-03-27T04:00:06+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=277
permalink: /2012/03/27/plunging-back-to-earth-from-the-iss/
categories:
  - Uncategorized
---
In response to my question on <a href="http://www.reddit.com/r/IAmA/comments/r62jp/iama_nasa_astronaut_that_recently_returned_to/" target="_blank">his reddit IAMA</a>, astronaut Ron Garan linked to this post he wrote on how it feels to plunge back to Earth from the ISS after more than 5 months in space. I found it incredibly interesting.

<div class="wp-caption aligncenter" style="width: 610px">
  <a href="http://fragileoasis.org/blog/2011/9/plunging-over-niagara-falls-in-a-burning-barrel-and-more/" target="_blank"><img class=" " title="Astronaut Ron Garan in descent capsule" src="http://www.fragileoasis.net/imgs/092211-Niagara/in-hatch.jpg" alt="" width="600" height="398" /></a>
  
  <p class="wp-caption-text">
    View from the International Space Station of Astronaut Ron Garan, with 2 others, just before their capsule door shut and it descended back to earth.
  </p>
</div>

http://fragileoasis.org/blog/2011/9/plunging-over-niagara-falls-in-a-burning-barrel-and-more/

Some quotes that stood out especially, to me:<!--more-->

> We all strapped into the same seats we occupied when we launched from the Baikonur Cosmodrome **in Kazakhstan**
> 
> &nbsp;
> 
> We approached Earth at a steep angle, at just under **5 miles per second
  
>** 
> 
> It was wonderful to speak with my family in Houston while we were all on **the same planet
  
>** 
> 
> &#8230;the realization that I would see **only one sunset each day**, instead of sixteen