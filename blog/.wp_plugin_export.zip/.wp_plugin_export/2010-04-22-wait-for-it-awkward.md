---
id: 34
title: 'Wait for it&#8230; awkward'
date: 2010-04-22T17:50:45+00:00
author: Jonathan Howard
layout: post
guid: http://staringispolite.com/blog/?p=34
permalink: /2010/04/22/wait-for-it-awkward/
categories:
  - humor
---
Non-sensical comeback gone awry at work. As opposed to the usual&#8230;

<div style="padding-left: 30px;">
  <strong>Them</strong>: &#8220;This is stupid.&#8221;<br /> <strong>You</strong>: &#8220;YOU&#8217;RE stupid.&#8221;
</div>

<div style="padding-left: 30px;">
</div>

It went something like this&#8230;

<div>
</div>

<div style="padding-left: 30px;">
  <strong>W</strong>: &#8220;Oh man, we missed the cycling class! I was thrown off by the sunlight&#8230; it feels like it&#8217;s 3!&#8221;<br /> <strong>Me</strong>: &#8220;You feel like you&#8217;re 3.&#8221;<br /> <strong>Both</strong>: &#8220;&#8230;&#8221;
</div>

<div>
</div>